from collections import Counter
word_list = []
with open('file1.txt','r') as f:
        for line in f:
                strip_lines=line.strip()
                listli=strip_lines.split()
                word_list = word_list + listli
        print(Counter(word_list).most_common())
